//! Numeric traits and implementations used across the workspace.

pub mod linalg;
pub mod num;

mod int;
